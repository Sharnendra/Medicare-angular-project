package com.medi.web.view;

public class QuantityInfoView {

	private int totalQuantity;
	private int availableQuantity;
	private float costPerQuantity;
	
	public int getTotalQuantity() {
		return totalQuantity;
	}
	public void setTotalQuantity(int totalQuantity) {
		this.totalQuantity = totalQuantity;
	}
	public int getAvailableQuantity() {
		return availableQuantity;
	}
	public void setAvailableQuantity(int availableQuantity) {
		this.availableQuantity = availableQuantity;
	}
	public float getCostPerQuantity() {
		return costPerQuantity;
	}
	public void setCostPerQuantity(float costPerQuantity) {
		this.costPerQuantity = costPerQuantity;
	}

}
