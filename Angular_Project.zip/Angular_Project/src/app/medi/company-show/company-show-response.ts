export interface CompanyShowResponse {
    companyName,
    createdDate,
    medicineName,
    modifiedDate
}