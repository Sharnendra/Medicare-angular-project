export interface CompanyInsertResponse2 {
    companyName,
    createdDate,
    medicineName,
    modifiedDate
}