export interface InvoiceInsertResponse {
    companyName,
    createdDate,
    medicineName,
    modifiedDate
}