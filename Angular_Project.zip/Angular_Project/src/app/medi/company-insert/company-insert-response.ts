export interface CompanyInsertResponse {
    companyName,
    createdDate,
    medicineName,
    modifiedDate
}