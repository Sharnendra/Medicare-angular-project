export interface LoginResponse {
  userId,
  userName,
  email,
  userRole
}